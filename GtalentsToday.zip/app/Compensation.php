<?php

namespace Vanguard;

use Illuminate\Database\Eloquent\Model;

class Compensation extends Model
{
    protected $table = 'compensations';

    public $primaryKey = 'id';

}
