<?php

namespace Vanguard\Events\Candidate;

class Created extends CandidateEvent {}
