<?php

namespace Vanguard\Events\Candidate;

class Deleted  extends CandidateEvent {}