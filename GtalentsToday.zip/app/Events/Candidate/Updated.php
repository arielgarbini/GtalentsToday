<?php

namespace Vanguard\Events\Candidate;

class Updated extends CandidateEvent {}
