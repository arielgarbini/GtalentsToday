<?php

namespace Vanguard\Events\Category;

class Created extends CategoryEvent {}
