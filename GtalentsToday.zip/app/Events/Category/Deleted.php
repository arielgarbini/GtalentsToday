<?php

namespace Vanguard\Events\Category;

class Deleted  extends CategoryEvent {}