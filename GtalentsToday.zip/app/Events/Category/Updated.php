<?php

namespace Vanguard\Events\Category;

class Updated extends CategoryEvent {}
