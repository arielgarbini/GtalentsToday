<?php

namespace Vanguard\Events\Company;

class Created extends CompanyEvent {}
