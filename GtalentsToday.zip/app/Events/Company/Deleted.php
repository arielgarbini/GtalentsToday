<?php

namespace Vanguard\Events\Company;

class Deleted  extends CompanyEvent {}