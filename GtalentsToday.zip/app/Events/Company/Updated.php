<?php

namespace Vanguard\Events\Company;

class Updated extends CompanyEvent {}
