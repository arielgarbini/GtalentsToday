<?php

namespace Vanguard\Events\Company;

class UpdatedCompanyExperience {}
