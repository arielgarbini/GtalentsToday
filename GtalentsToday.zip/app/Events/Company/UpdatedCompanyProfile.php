<?php

namespace Vanguard\Events\Company;

class UpdatedCompanyProfile {}
