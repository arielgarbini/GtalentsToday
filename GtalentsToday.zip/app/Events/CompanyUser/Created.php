<?php

namespace Vanguard\Events\CompanyUser;

class Created extends CompanyUserEvent {}
