<?php

namespace Vanguard\Events\CompanyUser;

class Deleted  extends CompanyUserEvent {}