<?php

namespace Vanguard\Events\CompanyUser;

class Updated extends CompanyUserEvent {}
