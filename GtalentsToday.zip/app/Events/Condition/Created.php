<?php

namespace Vanguard\Events\Condition;

class Created extends ConditionEvent {}
