<?php

namespace Vanguard\Events\Condition;

class Deleted  extends ConditionEvent {}