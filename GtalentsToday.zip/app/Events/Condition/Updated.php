<?php

namespace Vanguard\Events\Condition;

class Updated extends ConditionEvent {}
