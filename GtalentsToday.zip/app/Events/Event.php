<?php

namespace Vanguard\Events;

abstract class Event
{
    //
}
