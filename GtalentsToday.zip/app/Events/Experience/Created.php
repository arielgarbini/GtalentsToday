<?php

namespace Vanguard\Events\Experience;

class Created extends ExperienceEvent {}
