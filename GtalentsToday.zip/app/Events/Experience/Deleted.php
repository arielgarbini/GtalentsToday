<?php

namespace Vanguard\Events\Experience;

class Deleted extends ExperienceEvent {}