<?php

namespace Vanguard\Events\Experience;

class Updated extends ExperienceEvent {}
