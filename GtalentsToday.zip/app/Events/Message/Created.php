<?php

namespace Vanguard\Events\Message;

class Created extends MessageEvent {}
