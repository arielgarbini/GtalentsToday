<?php

namespace Vanguard\Events\Message;

class Deleted  extends MessageEvent {}