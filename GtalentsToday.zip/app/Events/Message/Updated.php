<?php

namespace Vanguard\Events\Message;

class Updated extends MessageEvent {}
