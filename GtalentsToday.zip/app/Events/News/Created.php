<?php

namespace Vanguard\Events\News;

class Created extends NewsEvent {}
