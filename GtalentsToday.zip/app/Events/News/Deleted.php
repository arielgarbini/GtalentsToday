<?php

namespace Vanguard\Events\News;

class Deleted  extends NewsEvent {}