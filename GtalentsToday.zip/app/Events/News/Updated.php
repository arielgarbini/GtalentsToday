<?php

namespace Vanguard\Events\News;

class Updated extends NewsEvent {}
