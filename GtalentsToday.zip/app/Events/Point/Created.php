<?php

namespace Vanguard\Events\Point;

class Created extends PointEvent {}
