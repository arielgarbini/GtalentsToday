<?php

namespace Vanguard\Events\Point;

class Deleted extends PointEvent {}