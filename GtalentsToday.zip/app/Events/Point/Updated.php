<?php

namespace Vanguard\Events\Point;

class Updated extends PointEvent {}
