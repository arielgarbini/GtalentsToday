<?php

namespace Vanguard\Events\Profile;

class Created extends ProfileEvent {}
