<?php

namespace Vanguard\Events\Profile;

class Deleted extends ProfileEvent {}