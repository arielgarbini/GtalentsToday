<?php

namespace Vanguard\Events\Profile;

class Updated extends ProfileEvent {}
