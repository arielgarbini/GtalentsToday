<?php

namespace Vanguard\Events\Vacancy;

class Applied extends VacancyEvent {}
