<?php

namespace Vanguard\Events\Vacancy;

class Created extends VacancyEvent {}
