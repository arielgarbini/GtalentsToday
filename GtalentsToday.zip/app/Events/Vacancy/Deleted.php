<?php

namespace Vanguard\Events\Vacancy;

class Deleted  extends VacancyEvent {}