<?php

namespace Vanguard\Events\Vacancy;

class Logged extends VacancyLogEvent {}
