<?php

namespace Vanguard\Events\Vacancy;

class Updated extends VacancyEvent {}
