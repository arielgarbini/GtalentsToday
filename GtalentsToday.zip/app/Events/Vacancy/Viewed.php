<?php

namespace Vanguard\Events\Vacancy;

class Viewed extends VacancyEvent {}
