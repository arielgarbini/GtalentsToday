<?php

namespace Vanguard\Events\VacancyUser;

class Created extends VacancyUserEvent {}
