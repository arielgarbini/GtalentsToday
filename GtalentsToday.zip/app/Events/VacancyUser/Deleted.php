<?php

namespace Vanguard\Events\VacancyUser;

class Deleted  extends VacancyUserEvent {}