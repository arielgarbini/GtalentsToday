<?php

namespace Vanguard\Events\VacancyUser;

class Updated extends VacancyUserEvent {}
