<?php

namespace Vanguard\Http\ViewComposers;

use Illuminate\View\View;

class PostsRecommendedComposer
{
    public function compose(View $view)
    {

    }
}
