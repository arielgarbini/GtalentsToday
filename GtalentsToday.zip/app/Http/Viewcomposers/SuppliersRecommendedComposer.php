<?php

namespace Vanguard\Http\ViewComposers;

use Illuminate\View\View;

class SuppliersRecommendedComposer
{
    public function compose(View $view)
    {

    }
}