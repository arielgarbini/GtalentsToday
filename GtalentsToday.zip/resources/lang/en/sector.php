<?php

return [
    'Retail' => 'Retail',
    'Security and Investigations' => 'Security and Investigations',
    'Semiconductors' 			  => 'Semiconductors',
    'Shipbuilding' 				  => 'Shipbuilding',
    'Sporting Goods' 			  => 'Sporting Goods',
];