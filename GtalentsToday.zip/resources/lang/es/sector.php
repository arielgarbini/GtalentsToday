<?php

return [
    'Retail' 					  => 'Retail',
    'Security and Investigations' => 'Seguridad e investigaciones',
    'Semiconductors' 			  => 'Semiconductores',
    'Shipbuilding' 				  => 'Construcción naval',
    'Sporting Goods' 			  => 'Artículos deportivos',
];